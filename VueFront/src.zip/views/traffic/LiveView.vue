<template>
  <router-view></router-view>
  <!-- 교통 상황 끝 -->
</template>

<script>
export default {
  name: "LiveView",
  data() {
    return {};
  },
};
</script>

<style></style>
