<template>
  <div class="footer">
    <div style="background-color: #e9ecef">
      <nav
        id="footer"
        class="container-fluid footer mt-5 py-3"
        style="
          --bs-breadcrumb-divider: url(
            &#34;data:image/svg + xml,
            %3Csvgxmlns='http://www.w3.org/2000/svg'width='8'height='8'%3E%3Cpathd='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z'fill='currentColor'/%3E%3C/svg%3E&#34;
          );
        "
        aria-label="breadcrumb"
      >
        <ul class="breadcrumb justify-content-end px-5 m-5">
          <li class="breadcrumb-item">
            <a href="#">소개</a>
          </li>
          <li class="breadcrumb-item">
            <a href="#">구해줘</a>
          </li>
          <li class="breadcrumb-item">
            <a href="#">게시판</a>
          </li>
        </ul>

        <div class="copyright px-5 m-2">
          <div class="row">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
              &copy; <a class="border-bottom" href="#">WhereIsMyHome</a>, All Right Reserved.
            </div>
            <div class="col-md-6 text-center text-md-end">
              Designed By <a class="border-bottom" href="#">team05</a>
            </div>
          </div>
        </div>
      </nav>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
